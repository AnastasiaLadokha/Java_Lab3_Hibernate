create function clear_cards(OUT id integer, OUT receipt_date date, OUT discharge_date date, OUT doctor_id integer, OUT patient_id integer, OUT disease_id integer, integer) returns SETOF record
    language sql
as
$$
DELETE FROM card WHERE doctor_id =$1 RETURNING *;
$$;

alter function clear_cards(out integer, out date, out date, out integer, out integer, out integer, integer) owner to postgres;

