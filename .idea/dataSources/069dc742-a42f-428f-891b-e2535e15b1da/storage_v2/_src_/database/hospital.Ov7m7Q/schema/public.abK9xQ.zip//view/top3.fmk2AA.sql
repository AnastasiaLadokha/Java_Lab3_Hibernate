create view top3("Number", name, last_name, "Count") as
SELECT x."Number",
       x.name,
       x.last_name,
       x."Count"
FROM (SELECT row_number() OVER (ORDER BY b."Count" DESC) AS "Number",
             b.name,
             b.last_name,
             b."Count"
      FROM (SELECT d.first_name AS name,
                   d.last_name,
                   count(*)     AS "Count"
            FROM card c,
                 doctor d
            WHERE c.doctor_id = d.id
            GROUP BY d.first_name, d.last_name) b
      GROUP BY b.name, b.last_name, b."Count") x
WHERE x."Number" < 4;

alter table top3
    owner to postgres;

