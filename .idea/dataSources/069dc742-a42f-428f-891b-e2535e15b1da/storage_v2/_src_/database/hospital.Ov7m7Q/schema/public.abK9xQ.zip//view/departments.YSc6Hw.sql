create view departments("Number", name, "Count") as
SELECT row_number() OVER (ORDER BY x."Count" DESC) AS "Number",
       x.name,
       x."Count"
FROM (SELECT dep.title AS name,
             dep.count_of_rooms,
             count(*)  AS "Count"
      FROM department dep,
           doctor doc
      WHERE dep.id = doc.department_id
      GROUP BY dep.title, dep.count_of_rooms) x
GROUP BY x.name, x."Count";

alter table departments
    owner to postgres;

