create view cards(first_name, last_name, "Count") as
SELECT x.first_name,
       x.last_name,
       x."Count"
FROM (SELECT p.first_name,
             p.last_name,
             count(*) AS "Count"
      FROM card c,
           patient p
      WHERE c.patient_id = p.id
      GROUP BY p.first_name, p.last_name) x
WHERE x."Count" > 1
GROUP BY x.first_name, x.last_name, x."Count";

alter table cards
    owner to postgres;

