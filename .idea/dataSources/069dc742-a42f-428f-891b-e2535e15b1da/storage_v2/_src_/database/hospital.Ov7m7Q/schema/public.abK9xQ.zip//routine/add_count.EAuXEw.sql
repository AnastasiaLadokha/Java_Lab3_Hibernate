create function add_count() returns trigger
    language plpgsql
as
$$
BEGIN
	UPDATE department
	SET count_of_doctors = count_of_doctors + 1
	WHERE id = NEW.department_id;
	
	UPDATE department dep
	SET count_of_doctors = (
		SELECT COUNT(*)
		FROM doctor doc
		WHERE dep.id = doc.department_id
	);
	RETURN NEW;
END;
$$;

alter function add_count() owner to postgres;

