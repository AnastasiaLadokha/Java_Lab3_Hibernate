create function remove_update_departments(integer) returns void
    language plpgsql
as
$$
DECLARE
	counter integer = 0;
	new_count integer = 0;
BEGIN
	SELECT COUNT(*) INTO counter FROM department WHERE count_of_rooms != $1;
	IF counter <= 0 THEN
	ELSE
	new_count = $1 / counter;
	DELETE FROM department WHERE count_of_rooms = $1;
	UPDATE department SET count_of_rooms = count_of_rooms + new_count;
	END IF;
	EXCEPTION 
	WHEN no_data_found THEN 
	RAISE NOTICE '%', SQLERRM;
END;
$$;

alter function remove_update_departments(integer) owner to postgres;

