create function prevention_of_error() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.receipt_date >= NEW.discharge_date THEN
		RAISE EXCEPTION 'Дата надходження не може бути пізнішою за дату виписки';
	END IF;
	RETURN NEW;
END;
$$;

alter function prevention_of_error() owner to postgres;

