create function old_cards() returns trigger
    language plpgsql
as
$$
BEGIN
	INSERT INTO old_card VALUES (OLD.id, OLD.receipt_date, OLD.discharge_date,
								 OLD.doctor_id, OLD.patient_id, OLD.disease_id);
	RETURN OLD;
END;
$$;

alter function old_cards() owner to postgres;

