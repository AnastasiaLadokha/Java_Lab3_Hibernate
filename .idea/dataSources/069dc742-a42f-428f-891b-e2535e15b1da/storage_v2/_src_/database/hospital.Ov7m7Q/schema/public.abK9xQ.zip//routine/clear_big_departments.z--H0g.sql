create function clear_big_departments() returns integer
    language plpgsql
as
$$
DECLARE
	counter integer = 0;
BEGIN
	SELECT COUNT(*) INTO counter FROM department WHERE count_of_rooms > 30;
	IF counter = 0 THEN RETURN 0;
	END IF;
	DELETE FROM department WHERE count_of_rooms > 30;
	RAISE NOTICE 'Видалено % рядків', counter;
	RETURN counter;
END;
$$;

alter function clear_big_departments() owner to postgres;

